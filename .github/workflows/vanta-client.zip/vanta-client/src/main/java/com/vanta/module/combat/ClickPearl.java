package com.vanta.module.combat;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

/** Auto-throws ender pearls when shift+right-click. */
public class ClickPearl extends Module {

    private long lastThrow = 0;

    public ClickPearl() {
        super("ClickPearl", "Throws ender pearls with a keybind", Category.COMBAT, GLFW.GLFW_KEY_G);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;
        if (System.currentTimeMillis() - lastThrow < 500) return;
        if (!mc.player.isSneaking()) return;

        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.ENDER_PEARL) {
                int prev = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = i;
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.swingHand(Hand.MAIN_HAND);
                mc.player.getInventory().selectedSlot = prev;
                lastThrow = System.currentTimeMillis();
                return;
            }
        }
    }
}
