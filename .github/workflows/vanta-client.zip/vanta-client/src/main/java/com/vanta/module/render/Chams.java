package com.vanta.module.render;

import com.vanta.module.Category;
import com.vanta.module.Module;
import org.lwjgl.glfw.GLFW;

/**
 * Chams: renders entities through walls with a solid flat color.
 * The actual rendering override is in MixinEntityRenderer (future impl).
 */
public class Chams extends Module {

    public static Chams INSTANCE;

    public Chams() {
        super("Chams", "See players through walls with solid color", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
        INSTANCE = this;
    }
}
