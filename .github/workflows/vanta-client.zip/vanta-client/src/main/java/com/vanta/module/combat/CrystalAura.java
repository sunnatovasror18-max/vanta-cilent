package com.vanta.module.combat;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import com.vanta.module.setting.BooleanSetting;
import com.vanta.module.setting.NumberSetting;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class CrystalAura extends Module {

    private final NumberSetting  range      = new NumberSetting("Range", 5.0, 1.0, 7.0, 0.5);
    private final NumberSetting  placeRange = new NumberSetting("PlaceRange", 4.5, 1.0, 6.0, 0.5);
    private final NumberSetting  minDmg     = new NumberSetting("MinDamage", 6.0, 0.0, 20.0, 0.5);
    private final NumberSetting  maxSelf    = new NumberSetting("MaxSelfDmg", 8.0, 0.0, 20.0, 0.5);
    private final BooleanSetting breakCryst = new BooleanSetting("Break", true);
    private final BooleanSetting placeCryst = new BooleanSetting("Place", true);
    private final BooleanSetting antiSuicide = new BooleanSetting("AntiSuicide", true);

    private long lastPlace = 0;
    private long lastBreak = 0;
    private static final long PLACE_DELAY = 200;
    private static final long BREAK_DELAY = 100;

    public CrystalAura() {
        super("CrystalAura", "Places and breaks end crystals for combat", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
        settings.add(range);
        settings.add(placeRange);
        settings.add(minDmg);
        settings.add(maxSelf);
        settings.add(breakCryst);
        settings.add(placeCryst);
        settings.add(antiSuicide);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        // ── Break phase ────────────────────────────────────────────
        if (breakCryst.getValue() && System.currentTimeMillis() - lastBreak >= BREAK_DELAY) {
            PlayerEntity target = findTarget();
            if (target != null) {
                for (Entity e : mc.world.getEntities()) {
                    if (!(e instanceof EndCrystalEntity crystal)) continue;
                    if (mc.player.distanceTo(crystal) > range.getValue()) continue;

                    float dmg   = calcDamage(crystal.getPos(), target);
                    float self  = calcDamage(crystal.getPos(), mc.player);

                    if (dmg >= minDmg.getValue()) {
                        if (antiSuicide.getValue() && self > mc.player.getHealth() + mc.player.getAbsorptionAmount()) continue;
                        if (self > maxSelf.getValue()) continue;
                        mc.interactionManager.attackEntity(mc.player, crystal);
                        mc.player.swingHand(Hand.MAIN_HAND);
                        lastBreak = System.currentTimeMillis();
                        break;
                    }
                }
            }
        }

        // ── Place phase ────────────────────────────────────────────
        if (placeCryst.getValue() && System.currentTimeMillis() - lastPlace >= PLACE_DELAY) {
            if (!hasCrystal()) return;
            PlayerEntity target = findTarget();
            if (target == null) return;

            BlockPos best = findBestPos(target);
            if (best == null) return;

            int prevSlot = switchToCrystal();
            if (prevSlot == -1) return;

            mc.interactionManager.interactBlock(
                mc.player,
                Hand.MAIN_HAND,
                new BlockHitResult(
                    Vec3d.ofCenter(best).add(0, 0.5, 0),
                    Direction.UP,
                    best,
                    false
                )
            );
            mc.player.swingHand(Hand.MAIN_HAND);
            lastPlace = System.currentTimeMillis();

            // restore slot
            mc.player.getInventory().selectedSlot = prevSlot;
        }
    }

    private PlayerEntity findTarget() {
        PlayerEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p)) continue;
            if (p == mc.player) continue;
            if (!p.isAlive()) continue;
            double d = mc.player.distanceTo(p);
            if (d < bestDist && d <= range.getValue()) {
                best = p;
                bestDist = d;
            }
        }
        return best;
    }

    private BlockPos findBestPos(PlayerEntity target) {
        List<BlockPos> candidates = new ArrayList<>();
        BlockPos origin = BlockPos.ofFloored(target.getPos());

        for (int x = -3; x <= 3; x++)
        for (int z = -3; z <= 3; z++) {
            BlockPos pos = origin.add(x, -1, z);
            if (!isValidPlacement(pos)) continue;
            if (mc.player.getPos().distanceTo(Vec3d.ofCenter(pos)) > placeRange.getValue()) continue;
            candidates.add(pos);
        }

        return candidates.stream()
            .max((a, b) -> {
                float dmgA = calcDamage(Vec3d.ofCenter(a).add(0, 1, 0), target);
                float dmgB = calcDamage(Vec3d.ofCenter(b).add(0, 1, 0), target);
                return Float.compare(dmgA, dmgB);
            }).orElse(null);
    }

    private boolean isValidPlacement(BlockPos pos) {
        var block = mc.world.getBlockState(pos).getBlock();
        if (block != Blocks.OBSIDIAN && block != Blocks.BEDROCK) return false;
        BlockPos above  = pos.up();
        BlockPos above2 = pos.up(2);
        return mc.world.getBlockState(above).isAir() && mc.world.getBlockState(above2).isAir();
    }

    /**
     * Simplified crystal damage calculation.
     * Real formula: damage = (1 - dist/12) * 10 * (difficulty multiplier)
     */
    private float calcDamage(Vec3d crystalPos, PlayerEntity player) {
        double dist = crystalPos.distanceTo(player.getPos());
        if (dist > 12) return 0;
        return (float) ((1.0 - dist / 12.0) * 10.0);
    }

    private boolean hasCrystal() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.END_CRYSTAL) return true;
        }
        return false;
    }

    /** Switches hotbar to end crystal; returns previous slot or -1. */
    private int switchToCrystal() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.END_CRYSTAL) {
                int prev = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = i;
                return prev;
            }
        }
        return -1;
    }
}
