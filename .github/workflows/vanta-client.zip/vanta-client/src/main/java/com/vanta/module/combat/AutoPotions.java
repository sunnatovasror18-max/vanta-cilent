package com.vanta.module.combat;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import com.vanta.module.setting.NumberSetting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Items;
import net.minecraft.item.PotionItem;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.potion.PotionContentsComponent;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class AutoPotions extends Module {

    private final NumberSetting hpThreshold = new NumberSetting("HP Threshold", 14.0, 1.0, 20.0, 1.0);

    public AutoPotions() {
        super("AutoPotions", "Throws heal/strength potions automatically", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
        settings.add(hpThreshold);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;
        if (mc.player.getHealth() > hpThreshold.getValue()) return;

        // Find splash health potion
        for (int i = 0; i < 9; i++) {
            var stack = mc.player.getInventory().getStack(i);
            if (!(stack.getItem() instanceof SplashPotionItem)) continue;

            var contents = stack.get(DataComponentTypes.POTION_CONTENTS);
            if (contents == null) continue;
            if (isHealPotion(contents)) {
                int prev = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = i;
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.getInventory().selectedSlot = prev;
                return;
            }
        }
    }

    private boolean isHealPotion(PotionContentsComponent contents) {
        return contents.getEffects().stream().anyMatch(e ->
            e.getEffectType().value().getName().getString().toLowerCase().contains("instant_health")
        );
    }
}
