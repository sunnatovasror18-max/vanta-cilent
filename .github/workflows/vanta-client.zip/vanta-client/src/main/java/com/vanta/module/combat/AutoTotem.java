package com.vanta.module.combat;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import com.vanta.module.setting.NumberSetting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public class AutoTotem extends Module {

    private final NumberSetting hpThreshold = new NumberSetting("HP Threshold", 20.0, 1.0, 20.0, 1.0);

    public AutoTotem() {
        super("AutoTotem", "Keeps a totem in your offhand", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
        settings.add(hpThreshold);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;

        ItemStack offhand = mc.player.getOffHandStack();
        if (offhand.getItem() == Items.TOTEM_OF_UNDYING) return;

        // Only act when HP is at or below threshold OR offhand is empty
        boolean lowHp    = mc.player.getHealth() <= hpThreshold.getValue();
        boolean noTotem  = offhand.isEmpty() || offhand.getItem() != Items.TOTEM_OF_UNDYING;
        if (!lowHp && !noTotem) return;

        // Find totem in inventory (skip hotbar for speed)
        int totemSlot = -1;
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) {
                totemSlot = i;
                break;
            }
        }
        if (totemSlot == -1) return;

        // 45 = offhand slot in the handler
        if (mc.currentScreen == null) {
            mc.player.getInventory();
            // Use screen handler to move totem to offhand
            mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId,
                totemSlot < 9 ? totemSlot + 36 : totemSlot,
                0,
                SlotActionType.PICKUP,
                mc.player
            );
            mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId,
                45, // offhand
                0,
                SlotActionType.PICKUP,
                mc.player
            );
            // Put back if cursor not empty
            mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId,
                totemSlot < 9 ? totemSlot + 36 : totemSlot,
                0,
                SlotActionType.PICKUP,
                mc.player
            );
        }
    }
}
