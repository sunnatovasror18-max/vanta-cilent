package com.vanta.module.setting;

public class ModeSetting extends Setting<String> {
    private final String[] modes;
    private       int      index;

    public ModeSetting(String name, String... modes) {
        super(name, modes[0]);
        this.modes = modes;
        this.index = 0;
    }

    public void next() {
        index = (index + 1) % modes.length;
        value = modes[index];
    }

    public boolean is(String mode) { return value.equalsIgnoreCase(mode); }
    public String[] getModes()     { return modes; }
}
