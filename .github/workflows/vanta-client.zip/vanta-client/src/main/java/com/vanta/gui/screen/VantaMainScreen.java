package com.vanta.gui.screen;

import com.vanta.VantaClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class VantaMainScreen extends Screen {

    private static final int BTN_W = 200;
    private static final int BTN_H = 20;

    public VantaMainScreen() {
        super(Text.literal("Vanta Client"));
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int cy = height / 2;

        // Singleplayer
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Singleplayer"),
            btn -> client.setScreen(new SelectWorldScreen(this))
        ).dimensions(cx - BTN_W / 2, cy - 28, BTN_W, BTN_H).build());

        // Multiplayer
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Multiplayer"),
            btn -> client.setScreen(new MultiplayerScreen(this))
        ).dimensions(cx - BTN_W / 2, cy - 4, BTN_W, BTN_H).build());

        // Options
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Options"),
            btn -> client.setScreen(new OptionsScreen(this, client.options))
        ).dimensions(cx - BTN_W / 2, cy + 20, BTN_W / 2 - 2, BTN_H).build());

        // Quit
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Quit"),
            btn -> client.stop()
        ).dimensions(cx + 2, cy + 20, BTN_W / 2 - 2, BTN_H).build());
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Panoramic/solid background
        ctx.fill(0, 0, width, height, 0xFF0A0A12);

        // Decorative gradient band at top
        ctx.fillGradient(0, 0, width, 60, 0xAA7B2FBE, 0x000A0A12);

        // Client name
        String title = "✦  VANTA  CLIENT";
        int tw = textRenderer.getWidth(title);
        ctx.drawTextWithShadow(textRenderer,
            Text.literal(title),
            (width - tw) / 2, height / 2 - 70, 0xFF7B2FBE);

        // Version tag
        String ver = "v" + VantaClient.VERSION + "  ·  Fabric 1.21.4";
        int vw = textRenderer.getWidth(ver);
        ctx.drawTextWithShadow(textRenderer,
            Text.literal(ver),
            (width - vw) / 2, height / 2 - 56, 0xFF555566);

        super.render(ctx, mx, my, delta);

        // Footer
        ctx.drawTextWithShadow(textRenderer,
            Text.literal("made for dj"),
            4, height - 10, 0xFF333344);
    }

    @Override
    public boolean shouldPause() { return false; }
}
