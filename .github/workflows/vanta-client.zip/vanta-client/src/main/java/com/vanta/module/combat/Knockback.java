package com.vanta.module.combat;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventPacketSend;
import com.vanta.module.Category;
import com.vanta.module.Module;
import com.vanta.module.setting.NumberSetting;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.lwjgl.glfw.GLFW;

/**
 * Sends extra movement packets to increase knockback dealt.
 * Also reduces knockback received (W-tap / reduce mode).
 */
public class Knockback extends Module {

    private final NumberSetting boost = new NumberSetting("Boost", 1.5, 0.5, 5.0, 0.1);

    public Knockback() {
        super("Knockback", "Increases knockback dealt", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
        settings.add(boost);
    }

    @EventHandler
    public void onPacket(EventPacketSend event) {
        // W-tap: briefly stop sprinting right after an attack to boost knockback
        // This is handled at the input level — stub for now
    }
}
