package com.vanta.module;

public enum Category {
    COMBAT  ("Combat",   0xFFE55050),
    MOVEMENT("Movement", 0xFF50C8E5),
    PLAYER  ("Player",   0xFF50E57A),
    RENDER  ("Render",   0xFFD050E5),
    MISC    ("Misc",     0xFFE5C850);

    public final String name;
    public final int    color;

    Category(String name, int color) {
        this.name  = name;
        this.color = color;
    }
}
