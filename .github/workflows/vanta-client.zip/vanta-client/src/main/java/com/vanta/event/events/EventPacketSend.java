package com.vanta.event.events;

import com.vanta.event.Cancellable;
import com.vanta.event.Event;
import net.minecraft.network.packet.Packet;

/** Fires before a C2S packet is sent. Cancel to block it. */
public class EventPacketSend extends Event implements Cancellable {
    public Packet<?> packet;
    private boolean  cancelled;

    public EventPacketSend(Packet<?> packet) { this.packet = packet; }

    @Override public boolean isCancelled()              { return cancelled; }
    @Override public void    setCancelled(boolean v)    { this.cancelled = v; }
}
