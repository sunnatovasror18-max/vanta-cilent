package com.vanta.module.movement;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventPacketSend;
import com.vanta.module.Category;
import com.vanta.module.Module;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.lwjgl.glfw.GLFW;

/** Freezes you in mid-air by canceling all position packets. */
public class AirStuck extends Module {

    public AirStuck() {
        super("AirStuck", "Freezes you mid-air", Category.MOVEMENT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    protected void onEnable() {
        if (mc.player != null) mc.player.setVelocity(0, 0, 0);
    }

    @EventHandler
    public void onPacket(EventPacketSend event) {
        if (event.packet instanceof PlayerMoveC2SPacket) {
            event.setCancelled(true);
        }
    }
}
