package com.vanta.mixin;

import com.vanta.VantaClient;
import com.vanta.event.events.EventRender2D;
import com.vanta.event.events.EventRender3D;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class MixinGameRenderer {

    @Inject(method = "renderWorld", at = @At("TAIL"))
    private void onRenderWorld(float tickDelta, long limitTime, MatrixStack matrices, CallbackInfo ci) {
        if (VantaClient.eventBus == null) return;
        VantaClient.eventBus.post(new EventRender3D(matrices, tickDelta));
    }
}
