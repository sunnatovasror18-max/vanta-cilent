package com.vanta.gui;

import com.vanta.VantaClient;
import com.vanta.module.Category;
import com.vanta.module.Module;
import com.vanta.module.setting.BooleanSetting;
import com.vanta.module.setting.NumberSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends Screen {

    // ── Panel layout ───────────────────────────────────────────────
    private static final int PANEL_W   = 110;
    private static final int PANEL_HDR = 16;
    private static final int MOD_H     = 14;
    private static final int PADDING   = 6;
    private static final int GAP       = 5;

    // Accent / bg colours
    private static final int COL_BG      = 0xCC0D0D0D;
    private static final int COL_HEADER  = 0xFF111111;
    private static final int COL_MOD_ON  = 0xFF1A1A2E;
    private static final int COL_MOD_OFF = 0xFF0D0D0D;
    private static final int COL_ACCENT  = 0xFF7B2FBE;
    private static final int COL_TEXT    = 0xFFE0E0E0;
    private static final int COL_DIM     = 0xFF888888;

    private final List<Panel> panels = new ArrayList<>();

    // Drag state
    private Panel  dragging;
    private int    dragOffX, dragOffY;

    public ClickGUI() {
        super(Text.literal("Vanta"));
        buildPanels();
    }

    private void buildPanels() {
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            panels.add(new Panel(cats[i], 10 + i * (PANEL_W + GAP), 40));
        }
    }

    // ── Screen overrides ──────────────────────────────────────────

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // dim background
        ctx.fill(0, 0, width, height, 0x80000000);

        for (Panel p : panels) p.render(ctx, mx, my);

        // Title bar
        ctx.fill(0, 0, width, 12, 0xFF0D0D0D);
        ctx.drawTextWithShadow(textRenderer,
            Text.literal("✦ Vanta  ·  RSHIFT to close"),
            4, 2, 0xFF7B2FBE);

        super.render(ctx, mx, my, delta);
    }

    // ── Mouse ─────────────────────────────────────────────────────

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        for (Panel p : panels) {
            if (p.headerHit(mx, my)) {
                dragging = p;
                dragOffX = (int) mx - p.x;
                dragOffY = (int) my - p.y;
                return true;
            }
            if (p.click(mx, my, btn)) return true;
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        dragging = null;
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging != null) {
            dragging.x = (int) mx - dragOffX;
            dragging.y = (int) my - dragOffY;
            return true;
        }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hScroll, double vScroll) {
        for (Panel p : panels) {
            if (p.contains(mx, my)) {
                p.scroll((int) vScroll);
                return true;
            }
        }
        return super.mouseScrolled(mx, my, hScroll, vScroll);
    }

    // ── Inner Panel class ─────────────────────────────────────────

    private class Panel {
        final Category cat;
        int x, y;
        boolean expanded = true;
        int scrollOff    = 0;
        Module openSettings = null;  // module whose settings are shown

        Panel(Category cat, int x, int y) {
            this.cat = cat;
            this.x   = x;
            this.y   = y;
        }

        List<Module> modules() {
            return VantaClient.moduleManager.getByCategory(cat);
        }

        int totalH() {
            if (!expanded) return PANEL_HDR;
            int h = PANEL_HDR;
            for (Module m : modules()) {
                h += MOD_H;
                if (m == openSettings) h += settingsH(m);
            }
            return h;
        }

        int settingsH(Module m) {
            return m.getSettings().size() * MOD_H;
        }

        boolean headerHit(double mx, double my) {
            return mx >= x && mx < x + PANEL_W && my >= y && my < y + PANEL_HDR;
        }

        boolean contains(double mx, double my) {
            return mx >= x && mx < x + PANEL_W && my >= y && my < y + totalH();
        }

        void scroll(int dir) { scrollOff = Math.max(0, scrollOff - dir * MOD_H); }

        // ── Render ─────────────────────────────────────────────────
        void render(DrawContext ctx, int mx, int my) {
            // Header
            int headerCol = cat.color & 0x44FFFFFF | 0xCC000000;
            ctx.fill(x, y, x + PANEL_W, y + PANEL_HDR, COL_HEADER);
            // Accent line under header
            ctx.fill(x, y + PANEL_HDR - 1, x + PANEL_W, y + PANEL_HDR, cat.color);
            ctx.drawTextWithShadow(textRenderer,
                Text.literal(cat.name), x + 4, y + 4, cat.color);

            // Collapse arrow
            String arrow = expanded ? "▼" : "▶";
            ctx.drawTextWithShadow(textRenderer,
                Text.literal(arrow), x + PANEL_W - 12, y + 4, COL_DIM);

            if (!expanded) return;

            int ry = y + PANEL_HDR - scrollOff;
            for (Module m : modules()) {
                if (ry + MOD_H < y + PANEL_HDR) { ry += MOD_H; continue; }
                if (ry > y + 400) break;

                // Module row
                int bg = m.isEnabled() ? COL_MOD_ON : COL_MOD_OFF;
                ctx.fill(x, ry, x + PANEL_W, ry + MOD_H, bg);

                // Enabled indicator bar
                if (m.isEnabled())
                    ctx.fill(x, ry, x + 2, ry + MOD_H, cat.color);

                int textCol = m.isEnabled() ? COL_TEXT : COL_DIM;
                ctx.drawTextWithShadow(textRenderer,
                    Text.literal(m.getName()), x + 5, ry + 3, textCol);

                // Settings gear icon
                if (!m.getSettings().isEmpty()) {
                    String icon = m == openSettings ? "✕" : "⚙";
                    ctx.drawTextWithShadow(textRenderer,
                        Text.literal(icon), x + PANEL_W - 12, ry + 3, COL_DIM);
                }

                ry += MOD_H;

                // Settings rows
                if (m == openSettings) {
                    for (var s : m.getSettings()) {
                        ctx.fill(x, ry, x + PANEL_W, ry + MOD_H, 0xFF060606);
                        String val = formatSetting(s);
                        ctx.drawTextWithShadow(textRenderer,
                            Text.literal("  " + s.getName() + ": " + val),
                            x + 4, ry + 3, 0xFF9B6FDE);
                        ry += MOD_H;
                    }
                }
            }
        }

        String formatSetting(com.vanta.module.setting.Setting<?> s) {
            if (s instanceof NumberSetting n)
                return String.format("%.1f", n.getValue());
            return String.valueOf(s.getValue());
        }

        // ── Click ──────────────────────────────────────────────────
        boolean click(double mx, double my, int btn) {
            if (!contains(mx, my)) return false;

            // Header → toggle expand
            if (headerHit(mx, my)) { expanded = !expanded; return true; }
            if (!expanded) return false;

            int ry = y + PANEL_HDR - scrollOff;
            for (Module m : modules()) {
                if (ry + MOD_H < y + PANEL_HDR) { ry += MOD_H; continue; }

                if (my >= ry && my < ry + MOD_H) {
                    boolean gearHit = mx >= x + PANEL_W - 14 && !m.getSettings().isEmpty();
                    if (gearHit) {
                        openSettings = (openSettings == m) ? null : m;
                    } else {
                        m.toggle();
                    }
                    return true;
                }
                ry += MOD_H;

                if (m == openSettings) {
                    for (var s : m.getSettings()) {
                        if (my >= ry && my < ry + MOD_H) {
                            handleSettingClick(s, btn);
                            return true;
                        }
                        ry += MOD_H;
                    }
                }
            }
            return false;
        }

        void handleSettingClick(com.vanta.module.setting.Setting<?> s, int btn) {
            if (s instanceof BooleanSetting b) {
                b.toggle();
            } else if (s instanceof NumberSetting n) {
                double step = n.getStep() * (btn == 1 ? -1 : 1);
                n.setValue(n.getValue() + step);
            } else if (s instanceof com.vanta.module.setting.ModeSetting m) {
                m.next();
            }
        }
    }
}
