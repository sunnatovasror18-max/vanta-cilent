package com.vanta.module;

import com.vanta.VantaClient;
import com.vanta.module.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {

    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    private final String   name;
    private final String   description;
    private final Category category;
    private       int      key;
    private       boolean  enabled;
    private       boolean  visible = true;

    protected final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, String description, Category category, int key) {
        this.name        = name;
        this.description = description;
        this.category    = category;
        this.key         = key;
    }

    /* ── Lifecycle ─────────────────────────────────────────────────── */

    public void toggle() {
        enabled = !enabled;
        if (enabled) {
            VantaClient.eventBus.subscribe(this);
            onEnable();
        } else {
            onDisable();
            VantaClient.eventBus.unsubscribe(this);
        }
    }

    public void setEnabled(boolean v) { if (v != enabled) toggle(); }

    protected void onEnable()  {}
    protected void onDisable() {}

    /* ── Getters ────────────────────────────────────────────────────── */

    public String   getName()        { return name;        }
    public String   getDescription() { return description; }
    public Category getCategory()    { return category;    }
    public int      getKey()         { return key;         }
    public boolean  isEnabled()      { return enabled;     }
    public boolean  isVisible()      { return visible;     }
    public List<Setting<?>> getSettings() { return settings; }

    public void setKey(int key)         { this.key     = key;     }
    public void setVisible(boolean v)   { this.visible = v;       }

    protected <T> T addSetting(Setting<T> s) { settings.add(s); return s.getValue(); }
}
