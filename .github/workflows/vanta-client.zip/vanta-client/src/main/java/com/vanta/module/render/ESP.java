package com.vanta.module.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.vanta.event.EventHandler;
import com.vanta.event.events.EventRender3D;
import com.vanta.module.Category;
import com.vanta.module.Module;
import com.vanta.module.setting.BooleanSetting;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

public class ESP extends Module {

    private final BooleanSetting players = new BooleanSetting("Players", true);
    private final BooleanSetting mobs    = new BooleanSetting("Mobs", true);

    public ESP() {
        super("ESP", "See entities through walls", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
        settings.add(players);
        settings.add(mobs);
    }

    @EventHandler
    public void onRender3D(EventRender3D event) {
        if (mc.player == null || mc.world == null) return;

        MatrixStack matrices = event.matrices;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player) continue;
            if (!e.isAlive()) continue;

            boolean isPlayer = e instanceof PlayerEntity;
            boolean isMob    = e instanceof MobEntity;

            if (isPlayer && !players.getValue()) continue;
            if (isMob    && !mobs.getValue())    continue;
            if (!isPlayer && !isMob) continue;

            float[] color = isPlayer ? new float[]{1f, 0.2f, 0.2f, 0.6f}
                                     : new float[]{0.2f, 1f, 0.2f, 0.6f};

            double x = e.getLerpedX(event.tickDelta) - cam.x;
            double y = e.getLerpedY(event.tickDelta) - cam.y;
            double z = e.getLerpedZ(event.tickDelta) - cam.z;

            Box box = e.getBoundingBox().offset(-cam.x + x - (e.getX() - cam.x),
                                                -cam.y + y - (e.getY() - cam.y),
                                                -cam.z + z - (e.getZ() - cam.z));

            drawBox(matrices, box, color[0], color[1], color[2], color[3]);
        }

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private void drawBox(MatrixStack matrices, Box box, float r, float g, float b, float a) {
        Tessellator tess   = Tessellator.getInstance();
        BufferBuilder buf  = tess.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        Matrix4f mat       = matrices.peek().getPositionMatrix();

        float x1 = (float) box.minX, y1 = (float) box.minY, z1 = (float) box.minZ;
        float x2 = (float) box.maxX, y2 = (float) box.maxY, z2 = (float) box.maxZ;

        // Bottom
        line(buf, mat, x1,y1,z1, x2,y1,z1, r,g,b,a);
        line(buf, mat, x2,y1,z1, x2,y1,z2, r,g,b,a);
        line(buf, mat, x2,y1,z2, x1,y1,z2, r,g,b,a);
        line(buf, mat, x1,y1,z2, x1,y1,z1, r,g,b,a);
        // Top
        line(buf, mat, x1,y2,z1, x2,y2,z1, r,g,b,a);
        line(buf, mat, x2,y2,z1, x2,y2,z2, r,g,b,a);
        line(buf, mat, x2,y2,z2, x1,y2,z2, r,g,b,a);
        line(buf, mat, x1,y2,z2, x1,y2,z1, r,g,b,a);
        // Verticals
        line(buf, mat, x1,y1,z1, x1,y2,z1, r,g,b,a);
        line(buf, mat, x2,y1,z1, x2,y2,z1, r,g,b,a);
        line(buf, mat, x2,y1,z2, x2,y2,z2, r,g,b,a);
        line(buf, mat, x1,y1,z2, x1,y2,z2, r,g,b,a);

        BufferRenderer.drawWithGlobalProgram(buf.end());
    }

    private void line(BufferBuilder b, Matrix4f m,
                      float x1,float y1,float z1,
                      float x2,float y2,float z2,
                      float r,float g,float bl,float a) {
        b.vertex(m, x1,y1,z1).color(r,g,bl,a);
        b.vertex(m, x2,y2,z2).color(r,g,bl,a);
    }
}
