package com.vanta.module.combat;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import net.minecraft.entity.LivingEntity;
import org.lwjgl.glfw.GLFW;

/**
 * Makes every hit a critical hit by making the player
 * "fall" just before attacking (tiny hop).
 */
public class Criticals extends Module {

    public Criticals() {
        super("Criticals", "Every hit becomes a critical", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        if (!mc.player.isOnGround()) return;
        if (mc.player.isInFluid()) return;
        if (mc.player.isRiding()) return;

        // Check if an entity is being targeted
        if (mc.targetedEntity instanceof LivingEntity) {
            // Tiny vertical boost — sets fallDistance > 0 so next hit = critical
            mc.player.setVelocity(mc.player.getVelocity().x, 0.11, mc.player.getVelocity().z);
        }
    }
}
