package com.vanta.module.misc;

import com.vanta.module.Category;
import com.vanta.module.Module;
import org.lwjgl.glfw.GLFW;

/** Replaces your name in chat/nametag with a fake one. */
public class NameProtect extends Module {

    private static final String FAKE_NAME = "Player";
    public static NameProtect INSTANCE;

    public NameProtect() {
        super("NameProtect", "Hides your real username", Category.MISC, GLFW.GLFW_KEY_UNKNOWN);
        INSTANCE = this;
    }

    /** Called from rendering / chat mixins to swap out the real name. */
    public static String protect(String text) {
        if (INSTANCE == null || !INSTANCE.isEnabled()) return text;
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc.player == null) return text;
        return text.replace(mc.player.getName().getString(), FAKE_NAME);
    }
}
