package com.vanta.module.combat;

import com.vanta.module.Category;
import com.vanta.module.Module;
import net.minecraft.entity.player.PlayerEntity;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Flags likely bot players so Aura / CrystalAura skips them.
 * Heuristics: ping == 0, entity ID pattern, invisible, etc.
 */
public class AntiBot extends Module {

    private static final Set<UUID> botCache = new HashSet<>();

    public AntiBot() {
        super("AntiBot", "Ignores bot players in combat", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
    }

    public static boolean isBot(PlayerEntity player) {
        if (!isBotEnabled()) return false;
        if (botCache.contains(player.getUuid())) return true;

        // Common tells:
        boolean noTabEntry = net.minecraft.client.MinecraftClient.getInstance()
            .getNetworkHandler() != null &&
            net.minecraft.client.MinecraftClient.getInstance()
            .getNetworkHandler().getPlayerListEntry(player.getUuid()) == null;

        if (noTabEntry) {
            botCache.add(player.getUuid());
            return true;
        }
        return false;
    }

    private static boolean isBotEnabled() {
        var mm = com.vanta.VantaClient.moduleManager;
        if (mm == null) return false;
        var mod = mm.get(AntiBot.class);
        return mod != null && mod.isEnabled();
    }
}
