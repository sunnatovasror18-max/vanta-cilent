package com.vanta.module.movement;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/** Lets the player climb any wall like a spider. */
public class Spider extends Module {

    public Spider() {
        super("Spider", "Climb any wall", Category.MOVEMENT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        if (mc.player.isOnGround()) return;

        // Check if there's a block adjacent to the player
        boolean touchingWall = isTouchingWall();
        if (!touchingWall) return;

        Vec3d vel = mc.player.getVelocity();
        // Climb upward when moving forward against a wall
        if (mc.options.forwardKey.isPressed()) {
            mc.player.setVelocity(vel.x, 0.2, vel.z);
        } else {
            mc.player.setVelocity(vel.x, Math.max(vel.y, 0), vel.z);
        }
    }

    private boolean isTouchingWall() {
        double x = mc.player.getX();
        double y = mc.player.getY();
        double z = mc.player.getZ();

        for (int dx = -1; dx <= 1; dx += 2) {
            BlockPos pos = BlockPos.ofFloored(x + dx * 0.6, y + 0.5, z);
            if (!mc.world.getBlockState(pos).isAir()) return true;
        }
        for (int dz = -1; dz <= 1; dz += 2) {
            BlockPos pos = BlockPos.ofFloored(x, y + 0.5, z + dz * 0.6);
            if (!mc.world.getBlockState(pos).isAir()) return true;
        }
        return false;
    }
}
