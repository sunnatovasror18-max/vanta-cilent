package com.vanta.module.combat;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import com.vanta.module.setting.BooleanSetting;
import com.vanta.module.setting.ModeSetting;
import com.vanta.module.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.Comparator;
import java.util.List;

public class Aura extends Module {

    private final NumberSetting  range    = new NumberSetting("Range", 4.0, 1.0, 6.0, 0.1);
    private final NumberSetting  cps      = new NumberSetting("CPS", 12.0, 1.0, 20.0, 1.0);
    private final ModeSetting    sort     = new ModeSetting("Sort", "Closest", "Health", "Angle");
    private final BooleanSetting rotate   = new BooleanSetting("Rotate", true);
    private final BooleanSetting players  = new BooleanSetting("Players", true);
    private final BooleanSetting mobs     = new BooleanSetting("Mobs", true);
    private final BooleanSetting stands   = new BooleanSetting("ArmorStands", false);

    private long lastAttack = 0;

    public Aura() {
        super("Aura", "Attacks nearby entities", Category.COMBAT, GLFW.GLFW_KEY_R);
        settings.add(range);
        settings.add(cps);
        settings.add(sort);
        settings.add(rotate);
        settings.add(players);
        settings.add(mobs);
        settings.add(stands);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        long now    = System.currentTimeMillis();
        long delay  = (long) (1000.0 / cps.getValue());
        if (now - lastAttack < delay) return;

        Entity target = getTarget();
        if (target == null) return;

        if (rotate.getValue()) {
            rotateTo(target);
        }

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        lastAttack = now;
    }

    private Entity getTarget() {
        List<Entity> entities = mc.world.getEntities().stream()
            .filter(this::isValid)
            .sorted(getComparator())
            .toList();
        return entities.isEmpty() ? null : entities.get(0);
    }

    private boolean isValid(Entity e) {
        if (e == mc.player) return false;
        if (!e.isAlive()) return false;
        if (mc.player.distanceTo(e) > range.getValue()) return false;
        if (e instanceof PlayerEntity p) {
            if (!players.getValue()) return false;
            if (p.isCreative()) return false;
        }
        if (e instanceof MobEntity && !mobs.getValue()) return false;
        if (e instanceof ArmorStandEntity && !stands.getValue()) return false;
        // Not a LivingEntity → skip
        return e instanceof LivingEntity;
    }

    private Comparator<Entity> getComparator() {
        if (sort.is("Health")) {
            return Comparator.comparingDouble(e -> ((LivingEntity) e).getHealth());
        }
        if (sort.is("Angle")) {
            return Comparator.comparingDouble(e -> getAngleDiff(e));
        }
        return Comparator.comparingDouble(e -> mc.player.distanceTo(e));
    }

    private double getAngleDiff(Entity e) {
        double[] angles = getAngles(e);
        double dyaw   = Math.abs(MathHelper.wrapDegrees(angles[0] - mc.player.getYaw()));
        double dpitch = Math.abs(MathHelper.wrapDegrees(angles[1] - mc.player.getPitch()));
        return dyaw + dpitch;
    }

    private void rotateTo(Entity e) {
        double[] angles = getAngles(e);
        mc.player.setYaw((float) angles[0]);
        mc.player.setPitch((float) angles[1]);
    }

    private double[] getAngles(Entity e) {
        double dx = e.getX() - mc.player.getX();
        double dy = (e.getY() + e.getHeight() * 0.5) - (mc.player.getY() + mc.player.getEyeHeight(mc.player.getPose()));
        double dz = e.getZ() - mc.player.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw   = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, dist)));
        return new double[]{ yaw, pitch };
    }
}
