package com.vanta.module.movement;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import com.vanta.module.setting.ModeSetting;
import com.vanta.module.setting.NumberSetting;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class Flight extends Module {

    private final ModeSetting  mode  = new ModeSetting("Mode", "Vanilla", "Elytra", "Packet");
    private final NumberSetting speed = new NumberSetting("Speed", 2.5, 0.1, 10.0, 0.1);

    private int packetTick = 0;

    public Flight() {
        super("Flight", "Lets you fly freely", Category.MOVEMENT, GLFW.GLFW_KEY_F);
        settings.add(mode);
        settings.add(speed);
    }

    @Override
    protected void onEnable() {
        if (mc.player == null) return;
        if (mode.is("Vanilla")) {
            mc.player.getAbilities().allowFlying = true;
            mc.player.getAbilities().flying      = true;
            mc.player.sendAbilitiesUpdate();
        }
    }

    @Override
    protected void onDisable() {
        if (mc.player == null) return;
        mc.player.getAbilities().allowFlying = false;
        mc.player.getAbilities().flying      = false;
        mc.player.sendAbilitiesUpdate();
        mc.player.setVelocity(0, 0, 0);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;

        switch (mode.getValue()) {
            case "Vanilla" -> handleVanilla();
            case "Elytra"  -> handleElytra();
            case "Packet"  -> handlePacket();
        }
    }

    private void handleVanilla() {
        mc.player.getAbilities().allowFlying = true;
        mc.player.getAbilities().flying      = true;

        Vec3d motion   = getMotionDir();
        double spd     = speed.getValue();
        double yMotion = 0;

        if (mc.options.jumpKey.isPressed())  yMotion =  spd;
        if (mc.options.sneakKey.isPressed()) yMotion = -spd;

        mc.player.setVelocity(motion.x * spd, yMotion, motion.z * spd);
    }

    private void handleElytra() {
        if (!mc.player.isFallFlying()) {
            mc.player.startFallFlying();
        }
        Vec3d dir = getMotionDir();
        mc.player.setVelocity(
            dir.x * speed.getValue(),
            0,
            dir.z * speed.getValue()
        );
    }

    private void handlePacket() {
        // Packet flight: alternate y-offsets to trick server anti-cheat
        packetTick++;
        double y = (packetTick % 2 == 0) ? 0.0625 : -0.0625;
        Vec3d dir = getMotionDir();
        mc.player.setVelocity(dir.x * speed.getValue(), y, dir.z * speed.getValue());
    }

    /** Returns normalized horizontal movement direction from key inputs. */
    private Vec3d getMotionDir() {
        float yaw = mc.player.getYaw();
        double rad = Math.toRadians(yaw);
        double mx = 0, mz = 0;

        if (mc.options.forwardKey.isPressed()) { mx -= Math.sin(rad); mz += Math.cos(rad); }
        if (mc.options.backKey.isPressed())    { mx += Math.sin(rad); mz -= Math.cos(rad); }
        if (mc.options.leftKey.isPressed())    { mx -= Math.cos(rad); mz -= Math.sin(rad); }
        if (mc.options.rightKey.isPressed())   { mx += Math.cos(rad); mz += Math.sin(rad); }

        double len = Math.sqrt(mx * mx + mz * mz);
        return len == 0 ? Vec3d.ZERO : new Vec3d(mx / len, 0, mz / len);
    }
}
