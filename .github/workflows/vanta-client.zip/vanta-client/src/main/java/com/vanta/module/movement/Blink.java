package com.vanta.module.movement;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventPacketSend;
import com.vanta.module.Category;
import com.vanta.module.Module;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Queue;

/**
 * Blink: holds movement packets while enabled,
 * then sends them all at once when toggled off.
 */
public class Blink extends Module {

    private final Queue<Packet<?>> packetQueue = new ArrayDeque<>();

    public Blink() {
        super("Blink", "Hold movement packets and teleport", Category.MOVEMENT, GLFW.GLFW_KEY_B);
    }

    @Override
    protected void onDisable() {
        // Flush all held packets
        if (mc.getNetworkHandler() != null) {
            for (Packet<?> p : packetQueue) {
                mc.getNetworkHandler().sendPacket(p);
            }
        }
        packetQueue.clear();
    }

    @EventHandler
    public void onPacket(EventPacketSend event) {
        if (event.packet instanceof PlayerMoveC2SPacket) {
            packetQueue.add(event.packet);
            event.setCancelled(true);
        }
    }

    public int getQueueSize() { return packetQueue.size(); }
}
