package com.vanta;

import com.vanta.event.EventBus;
import com.vanta.gui.ClickGUI;
import com.vanta.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public class VantaClient implements ClientModInitializer {

    public static final String NAME    = "Vanta";
    public static final String VERSION = "1.0";

    public static MinecraftClient mc = MinecraftClient.getInstance();
    public static EventBus        eventBus;
    public static ModuleManager   moduleManager;
    public static ClickGUI        clickGUI;

    private static VantaClient INSTANCE;

    @Override
    public void onInitializeClient() {
        INSTANCE      = this;
        eventBus      = new EventBus();
        moduleManager = new ModuleManager();
        clickGUI      = new ClickGUI();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            moduleManager.onTick();
        });

        System.out.println("[" + NAME + "] v" + VERSION + " loaded — dj's bench.");
    }

    public static VantaClient getInstance() { return INSTANCE; }
}
