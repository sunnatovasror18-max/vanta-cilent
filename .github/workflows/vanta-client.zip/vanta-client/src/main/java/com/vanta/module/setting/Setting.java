package com.vanta.module.setting;

public abstract class Setting<T> {
    protected final String name;
    protected       T      value;

    public Setting(String name, T defaultValue) {
        this.name  = name;
        this.value = defaultValue;
    }

    public String getName()       { return name;  }
    public T      getValue()      { return value; }
    public void   setValue(T val) { this.value = val; }
}
