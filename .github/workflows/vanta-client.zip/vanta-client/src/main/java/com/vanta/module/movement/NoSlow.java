package com.vanta.module.movement;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventPacketSend;
import com.vanta.module.Category;
import com.vanta.module.Module;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/**
 * Prevents slowing while using items (eating, drinking, blocking, using bow).
 * Done by canceling the slowdown applied by the PlayerEntity input handler.
 */
public class NoSlow extends Module {

    public NoSlow() {
        super("NoSlow", "Don't slow while using items", Category.MOVEMENT, GLFW.GLFW_KEY_UNKNOWN);
    }

    // The actual NoSlow is applied in MixinKeyboardInput (see mixin)
    // This module just acts as a flag checked by the mixin.
    public static boolean isActive() {
        var mm = com.vanta.VantaClient.moduleManager;
        if (mm == null) return false;
        var m = mm.get(NoSlow.class);
        return m != null && m.isEnabled();
    }
}
