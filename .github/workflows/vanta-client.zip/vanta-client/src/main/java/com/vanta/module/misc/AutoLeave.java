package com.vanta.module.misc;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import com.vanta.module.setting.NumberSetting;
import net.minecraft.client.gui.screen.TitleScreen;
import org.lwjgl.glfw.GLFW;

/** Disconnects automatically when your HP drops below a threshold. */
public class AutoLeave extends Module {

    private final NumberSetting hpThreshold = new NumberSetting("HP", 4.0, 1.0, 20.0, 1.0);

    public AutoLeave() {
        super("AutoLeave", "Auto-disconnect on low HP", Category.MISC, GLFW.GLFW_KEY_UNKNOWN);
        settings.add(hpThreshold);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;
        if (mc.player.getHealth() > hpThreshold.getValue()) return;

        mc.world.disconnect();
        mc.setScreen(new TitleScreen());
        setEnabled(false);
    }
}
