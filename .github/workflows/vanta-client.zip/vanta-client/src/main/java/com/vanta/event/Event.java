package com.vanta.event;

public abstract class Event {}
