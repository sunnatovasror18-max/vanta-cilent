package com.vanta.event;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventBus {

    private final Map<Class<?>, List<ListenerEntry>> listeners = new HashMap<>();

    public void subscribe(Object obj) {
        for (Method method : obj.getClass().getDeclaredMethods()) {
            if (method.isAnnotationPresent(EventHandler.class) && method.getParameterCount() == 1) {
                Class<?> type = method.getParameterTypes()[0];
                listeners.computeIfAbsent(type, k -> new CopyOnWriteArrayList<>())
                         .add(new ListenerEntry(obj, method));
            }
        }
    }

    public void unsubscribe(Object obj) {
        listeners.values().forEach(list -> list.removeIf(e -> e.target == obj));
    }

    public <T extends Event> T post(T event) {
        List<ListenerEntry> entries = listeners.get(event.getClass());
        if (entries != null) {
            for (ListenerEntry entry : entries) {
                if (event instanceof Cancellable c && c.isCancelled()) break;
                try { entry.method.invoke(entry.target, event); }
                catch (Exception ignored) {}
            }
        }
        return event;
    }

    private static class ListenerEntry {
        final Object target;
        final Method method;
        ListenerEntry(Object target, Method method) {
            this.target = target;
            this.method = method;
            method.setAccessible(true);
        }
    }
}
