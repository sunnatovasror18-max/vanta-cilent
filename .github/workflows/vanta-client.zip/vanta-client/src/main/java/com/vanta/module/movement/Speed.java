package com.vanta.module.movement;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import com.vanta.module.setting.ModeSetting;
import com.vanta.module.setting.NumberSetting;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class Speed extends Module {

    private final ModeSetting  mode  = new ModeSetting("Mode", "Strafe", "Boost");
    private final NumberSetting spd  = new NumberSetting("Speed", 1.6, 0.1, 5.0, 0.1);

    public Speed() {
        super("Speed", "Move faster", Category.MOVEMENT, GLFW.GLFW_KEY_V);
        settings.add(mode);
        settings.add(spd);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;
        if (!isMoving()) return;

        Vec3d vel = mc.player.getVelocity();

        if (mode.is("Strafe")) {
            float yaw = mc.player.getYaw();
            double rad = Math.toRadians(yaw);
            double mx = -Math.sin(rad), mz = Math.cos(rad);
            mc.player.setVelocity(mx * spd.getValue(), vel.y, mz * spd.getValue());
        } else {
            // Boost — multiply existing horizontal
            double len = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
            if (len > 0) {
                double mult = spd.getValue() / len;
                mc.player.setVelocity(vel.x * mult, vel.y, vel.z * mult);
            }
        }
    }

    private boolean isMoving() {
        return mc.options.forwardKey.isPressed()
            || mc.options.backKey.isPressed()
            || mc.options.leftKey.isPressed()
            || mc.options.rightKey.isPressed();
    }
}
