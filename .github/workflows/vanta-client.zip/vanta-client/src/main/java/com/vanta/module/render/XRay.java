package com.vanta.module.render;

import com.vanta.module.Category;
import com.vanta.module.Module;
import net.minecraft.block.*;
import org.lwjgl.glfw.GLFW;

import java.util.Set;

/**
 * XRay: makes non-ore blocks transparent.
 * Actual transparency logic lives in MixinAbstractBlockState.
 * This module is the flag + ore list.
 */
public class XRay extends Module {

    public static XRay INSTANCE;

    /** Blocks that remain visible during XRay. */
    private static final Set<Block> ORES = Set.of(
        Blocks.DIAMOND_ORE,
        Blocks.DEEPSLATE_DIAMOND_ORE,
        Blocks.EMERALD_ORE,
        Blocks.DEEPSLATE_EMERALD_ORE,
        Blocks.GOLD_ORE,
        Blocks.DEEPSLATE_GOLD_ORE,
        Blocks.IRON_ORE,
        Blocks.DEEPSLATE_IRON_ORE,
        Blocks.COPPER_ORE,
        Blocks.DEEPSLATE_COPPER_ORE,
        Blocks.COAL_ORE,
        Blocks.DEEPSLATE_COAL_ORE,
        Blocks.LAPIS_ORE,
        Blocks.DEEPSLATE_LAPIS_ORE,
        Blocks.REDSTONE_ORE,
        Blocks.DEEPSLATE_REDSTONE_ORE,
        Blocks.NETHER_GOLD_ORE,
        Blocks.NETHER_QUARTZ_ORE,
        Blocks.ANCIENT_DEBRIS,
        Blocks.CHEST,
        Blocks.TRAPPED_CHEST,
        Blocks.ENDER_CHEST,
        Blocks.SPAWNER
    );

    public XRay() {
        super("XRay", "See ores through blocks", Category.RENDER, GLFW.GLFW_KEY_X);
        INSTANCE = this;
    }

    @Override
    protected void onEnable()  { reloadChunks(); }

    @Override
    protected void onDisable() { reloadChunks(); }

    private void reloadChunks() {
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }

    public boolean isOre(Block block) { return ORES.contains(block); }
}
