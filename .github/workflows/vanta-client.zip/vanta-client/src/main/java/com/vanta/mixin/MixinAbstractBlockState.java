package com.vanta.mixin;

import com.vanta.module.render.XRay;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.world.BlockView;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractBlock.AbstractBlockState.class)
public abstract class MixinAbstractBlockState {

    @Shadow public abstract Block getBlock();

    @Inject(method = "isOpaqueFullCube", at = @At("HEAD"), cancellable = true)
    private void onIsOpaque(BlockView world, BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        if (XRay.INSTANCE != null && XRay.INSTANCE.isEnabled()) {
            if (!XRay.INSTANCE.isOre(getBlock())) {
                cir.setReturnValue(false);
            }
        }
    }
}
