package com.vanta.module.combat;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import net.minecraft.item.SwordItem;
import org.lwjgl.glfw.GLFW;

/** Switches to best sword when a target is in range. */
public class AutoSwap extends Module {

    public AutoSwap() {
        super("AutoSwap", "Switches to best sword automatically", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;
        if (mc.player.getMainHandStack().getItem() instanceof SwordItem) return;

        int bestSlot  = -1;
        int bestDmg   = -1;
        for (int i = 0; i < 9; i++) {
            var stack = mc.player.getInventory().getStack(i);
            if (!(stack.getItem() instanceof SwordItem s)) continue;
            // Use attack damage from item (approximate)
            if (bestDmg < 0) { bestSlot = i; bestDmg = 0; }
            // first sword found wins (could improve with enchant comparison)
        }
        if (bestSlot != -1) mc.player.getInventory().selectedSlot = bestSlot;
    }
}
