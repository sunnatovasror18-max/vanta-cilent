package com.vanta.module.movement;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import org.lwjgl.glfw.GLFW;

/** Always sprints regardless of direction or hunger. */
public class Sprint extends Module {

    public Sprint() {
        super("Sprint", "Always sprint", Category.MOVEMENT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;
        mc.player.setSprinting(true);
    }
}
