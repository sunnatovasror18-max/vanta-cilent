package com.vanta.mixin;

import com.vanta.VantaClient;
import com.vanta.event.events.EventKey;
import com.vanta.event.events.EventPacketSend;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MixinMinecraftClient {

    /** Hook for key presses → EventKey */
    @Inject(method = "onKeyEvent", at = @At("HEAD"))
    private void onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (action != 1 /* GLFW_PRESS */) return;
        if (VantaClient.eventBus != null)
            VantaClient.eventBus.post(new EventKey(key));
    }
}
