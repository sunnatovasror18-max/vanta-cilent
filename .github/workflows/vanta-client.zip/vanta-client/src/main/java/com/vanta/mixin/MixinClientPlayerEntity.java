package com.vanta.mixin;

import com.vanta.VantaClient;
import com.vanta.event.events.EventPacketSend;
import net.minecraft.client.network.ClientCommonNetworkHandler;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientCommonNetworkHandler.class)
public class MixinClientPlayerEntity {

    @Inject(method = "sendPacket(Lnet/minecraft/network/packet/Packet;)V",
            at = @At("HEAD"), cancellable = true)
    private void onSendPacket(Packet<?> packet, CallbackInfo ci) {
        if (VantaClient.eventBus == null) return;
        var event = VantaClient.eventBus.post(new EventPacketSend(packet));
        if (event.isCancelled()) ci.cancel();
    }
}
