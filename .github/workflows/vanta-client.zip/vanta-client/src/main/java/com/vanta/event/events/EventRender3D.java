package com.vanta.event.events;

import com.vanta.event.Event;
import net.minecraft.client.util.math.MatrixStack;

/** Fires during world rendering (before entities). */
public class EventRender3D extends Event {
    public final MatrixStack matrices;
    public final float       tickDelta;

    public EventRender3D(MatrixStack matrices, float tickDelta) {
        this.matrices  = matrices;
        this.tickDelta = tickDelta;
    }
}
