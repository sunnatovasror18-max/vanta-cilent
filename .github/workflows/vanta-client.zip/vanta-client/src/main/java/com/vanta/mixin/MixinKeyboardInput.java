package com.vanta.mixin;

import com.vanta.module.movement.NoSlow;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cancels the 0.2x slowdown Minecraft applies while holding an item
 * (eating, drinking, blocking, bow charging).
 */
@Mixin(KeyboardInput.class)
public class MixinKeyboardInput {

    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(boolean slowDown, float f, CallbackInfo ci) {
        if (!NoSlow.isActive()) return;

        KeyboardInput self = (KeyboardInput)(Object)this;
        // Restore full movement speed by writing back 1.0 multiplier
        // The actual field names from Yarn 1.21.4:
        self.movementForward  = self.movementForward  < 0 ? -1f : (self.movementForward  > 0 ? 1f : 0f);
        self.movementSideways = self.movementSideways < 0 ? -1f : (self.movementSideways > 0 ? 1f : 0f);
    }
}
