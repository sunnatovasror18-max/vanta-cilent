package com.vanta.module.combat;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.*;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public class AutoArmor extends Module {

    public AutoArmor() {
        super("AutoArmor", "Equips best armor automatically", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;

        EquipmentSlot[] armorSlots = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST,
            EquipmentSlot.LEGS, EquipmentSlot.FEET
        };
        int[] screenSlots = { 5, 6, 7, 8 }; // head, chest, legs, feet in screen handler

        for (int s = 0; s < armorSlots.length; s++) {
            EquipmentSlot slot = armorSlots[s];
            ItemStack current  = mc.player.getEquippedStack(slot);

            int bestSlot = -1;
            int bestProt = getProtection(current);

            for (int i = 9; i < 45; i++) {
                ItemStack stack = mc.player.getInventory().getStack(
                    i < 36 ? i : i - 36 // map to inventory
                );
                if (!fitsSlot(stack, slot)) continue;
                int prot = getProtection(stack);
                if (prot > bestProt) {
                    bestProt = prot;
                    bestSlot = i;
                }
            }

            if (bestSlot == -1) continue;

            // Swap
            mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId,
                bestSlot, 0, SlotActionType.PICKUP, mc.player
            );
            mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId,
                screenSlots[s], 0, SlotActionType.PICKUP, mc.player
            );
            if (!mc.player.playerScreenHandler.getCursorStack().isEmpty()) {
                mc.interactionManager.clickSlot(
                    mc.player.playerScreenHandler.syncId,
                    bestSlot, 0, SlotActionType.PICKUP, mc.player
                );
            }
            return; // one per tick
        }
    }

    private int getProtection(ItemStack stack) {
        if (stack.isEmpty()) return 0;
        if (stack.getItem() instanceof ArmorItem a) return a.getProtection();
        return 0;
    }

    private boolean fitsSlot(ItemStack stack, EquipmentSlot slot) {
        if (stack.isEmpty()) return false;
        return stack.getItem() instanceof ArmorItem a && a.getSlotType() == slot;
    }
}
