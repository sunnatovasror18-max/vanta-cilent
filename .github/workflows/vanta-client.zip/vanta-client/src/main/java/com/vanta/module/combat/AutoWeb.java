package com.vanta.module.combat;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import org.lwjgl.glfw.GLFW;

/** Places cobwebs under/on targets to slow them. */
public class AutoWeb extends Module {

    public AutoWeb() {
        super("AutoWeb", "Places cobwebs on enemies", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        if (!hasWeb()) return;

        LivingEntity target = mc.world.getEntities().stream()
            .filter(e -> e instanceof LivingEntity && e != mc.player && e.isAlive())
            .filter(e -> mc.player.distanceTo(e) < 4.5)
            .map(e -> (LivingEntity) e)
            .findFirst().orElse(null);

        if (target == null) return;

        BlockPos pos = BlockPos.ofFloored(target.getPos());
        if (!mc.world.getBlockState(pos).isAir()) pos = pos.up();
        if (!mc.world.getBlockState(pos).isAir()) return;

        int prev = switchToWeb();
        if (prev == -1) return;

        mc.interactionManager.interactBlock(
            mc.player, Hand.MAIN_HAND,
            new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos.down(), false)
        );
        mc.player.swingHand(Hand.MAIN_HAND);
        mc.player.getInventory().selectedSlot = prev;
    }

    private boolean hasWeb() {
        for (int i = 0; i < 9; i++)
            if (mc.player.getInventory().getStack(i).getItem() == Items.COBWEB) return true;
        return false;
    }

    private int switchToWeb() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.COBWEB) {
                int p = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = i;
                return p;
            }
        }
        return -1;
    }
}
