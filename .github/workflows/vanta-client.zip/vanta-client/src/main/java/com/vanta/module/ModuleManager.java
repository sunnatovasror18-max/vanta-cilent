package com.vanta.module;

import com.vanta.VantaClient;
import com.vanta.event.EventHandler;
import com.vanta.event.events.EventKey;
import com.vanta.module.combat.*;
import com.vanta.module.movement.*;
import com.vanta.module.render.*;
import com.vanta.module.misc.*;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // ── Combat ─────────────────────────────────────────────────
        add(new Aura());
        add(new CrystalAura());
        add(new AutoTotem());
        add(new AutoArmor());
        add(new AutoPotions());
        add(new AutoSwap());
        add(new Criticals());
        add(new AntiBot());
        add(new Knockback());
        add(new AutoWeb());
        add(new ClickPearl());

        // ── Movement ────────────────────────────────────────────────
        add(new Flight());
        add(new Speed());
        add(new Sprint());
        add(new NoSlow());
        add(new Spider());
        add(new Blink());
        add(new AirStuck());

        // ── Render ──────────────────────────────────────────────────
        add(new XRay());
        add(new ESP());
        add(new Chams());
        add(new Fullbright());

        // ── Misc ────────────────────────────────────────────────────
        add(new NameProtect());
        add(new AutoLeave());

        VantaClient.eventBus.subscribe(this);
    }

    private void add(Module m) { modules.add(m); }

    public void onTick() {
        VantaClient.eventBus.post(new com.vanta.event.events.EventUpdate());
    }

    @EventHandler
    public void onKey(EventKey event) {
        // RSHIFT → open/close ClickGUI
        if (event.keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            var mc = net.minecraft.client.MinecraftClient.getInstance();
            if (mc.currentScreen == null) {
                mc.setScreen(VantaClient.clickGUI);
            }
            return;
        }
        for (Module m : modules) {
            if (m.getKey() == event.keyCode) m.toggle();
        }
    }

    /* ── Queries ──────────────────────────────────────────────────── */

    public List<Module> getAll()   { return modules; }

    public List<Module> getByCategory(Category cat) {
        return modules.stream().filter(m -> m.getCategory() == cat).toList();
    }

    public List<Module> getEnabled() {
        return modules.stream().filter(Module::isEnabled).toList();
    }

    /** Sorted by name length descending (for HUD display). */
    public List<Module> getEnabledSorted() {
        return modules.stream()
                      .filter(Module::isEnabled)
                      .filter(Module::isVisible)
                      .sorted(Comparator.comparingInt(m -> -m.getName().length()))
                      .toList();
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> clazz) {
        return (T) modules.stream().filter(m -> m.getClass() == clazz).findFirst().orElse(null);
    }
}
