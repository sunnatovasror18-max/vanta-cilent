package com.vanta.event.events;

import com.vanta.event.Event;

/** Fires every client tick (pre-movement). */
public class EventUpdate extends Event {}
