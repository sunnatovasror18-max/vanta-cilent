package com.vanta.module.render;

import com.vanta.event.EventHandler;
import com.vanta.event.events.EventUpdate;
import com.vanta.module.Category;
import com.vanta.module.Module;
import org.lwjgl.glfw.GLFW;

/** Sets gamma to max so everything is fully lit. */
public class Fullbright extends Module {

    private double prevGamma = 1.0;

    public Fullbright() {
        super("Fullbright", "Removes all darkness", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    protected void onEnable() {
        if (mc.options != null) {
            prevGamma = mc.options.getGamma().getValue();
            mc.options.getGamma().setValue(16.0);
        }
    }

    @Override
    protected void onDisable() {
        if (mc.options != null) mc.options.getGamma().setValue(prevGamma);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        // Keep gamma locked while enabled
        if (mc.options != null && mc.options.getGamma().getValue() < 16.0) {
            mc.options.getGamma().setValue(16.0);
        }
    }
}
