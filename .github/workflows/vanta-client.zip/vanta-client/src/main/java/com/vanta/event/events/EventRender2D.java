package com.vanta.event.events;

import com.vanta.event.Event;
import net.minecraft.client.gui.DrawContext;

/** Fires during HUD rendering. */
public class EventRender2D extends Event {
    public final DrawContext context;
    public final float       tickDelta;

    public EventRender2D(DrawContext context, float tickDelta) {
        this.context   = context;
        this.tickDelta = tickDelta;
    }
}
