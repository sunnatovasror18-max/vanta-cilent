package com.vanta.event.events;

import com.vanta.event.Event;

public class EventKey extends Event {
    public final int keyCode;
    public EventKey(int keyCode) { this.keyCode = keyCode; }
}
